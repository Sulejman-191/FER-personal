//#include <nvtx3/nvToolsExt.h>

void jacobistep(double *psinew, double *psi, int m, int n);

double deltasq(double *newarr, double *oldarr, int m, int n);
