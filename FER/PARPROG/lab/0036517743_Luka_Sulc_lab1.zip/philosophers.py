import random
import time
from enum import Enum
from mpi4py import MPI


class ForkStates(Enum):
    empty = ''
    '''
    doesn't have the fork
    '''
    clean = 'clean'
    '''
    has the fork and clean
    '''
    dirty = 'dirty'
    '''
    has the fork but dirty
    '''


class ForkRequests(Enum):
    need_right = 'right_fork'
    need_left = 'left_fork'


class Philosopher:
    def __init__(self, philosopher_id, right_fork=ForkStates.empty, left_fork=ForkStates.empty):
        self.id = philosopher_id
        self.right_fork = right_fork
        self.left_fork = left_fork
        self.request_queue = []

    def __str__(self):
        return "    " * self.id + f"P[{self.id}]"

    def has_forks(self):
        return False if self.right_fork == ForkStates.empty or self.left_fork == ForkStates.empty else True

    def get_forks_dirty(self):
        self.right_fork = ForkStates.dirty
        self.left_fork = ForkStates.dirty

    # def get_clean_forks(self):
    #     self.right_fork = ForkStates.clean
    #     self.left_fork = ForkStates.clean


def req_fork_and_wait_resp(_p: Philosopher, dest_id, fork_req=ForkRequests.need_right):
    print(f"{_p} requesting {fork_req.value} fork from P[{dest_id}]", flush=True)
    comm.send({"id": _p.id, "req": fork_req}, dest=dest_id)
    _message = comm.recv()
    print(f"{_p} received message: {_message}, my req: {fork_req.value}", flush=True)

    while not _message.get("rsp"):
        request = _message.get("req")
        if not request:
            raise Exception(f"{_p} message is not 'res' or 'req'! Message: {_message}")

        if request == ForkRequests.need_right:  # his right fork is my left fork
            if _p.left_fork == ForkStates.dirty:  # if fork dirty send immediately
                send_rsp(_p, _message)
            elif _p.left_fork == ForkStates.clean:  # if fork clean than it's mine! others wait
                _p.request_queue.append(_message)
                print(f"{_p} message queued: {_message}")
            else:
                raise Exception(f"{_p} me and {_message['id']} lost a fork! Message: {_message}")

        elif request == ForkRequests.need_left:  # his left fork is my right fork
            if _p.right_fork == ForkStates.dirty:  # if fork dirty send immediately
                send_rsp(_p, _message)
            elif _p.right_fork == ForkStates.clean:  # if fork clean than it's mine! others wait
                _p.request_queue.append(_message)
                print(f"{_p} message queued: {_message}")
            else:
                raise Exception(f"{_p} me and {_message['id']} lost a fork! Message: {_message}")
        else:
            raise Exception("Unknown request:", request)

        _message = comm.recv()
        print(f"{_p} received message: {_message}, my req: {fork_req.value}", flush=True)

    # while loop ended => message has 'rsp' == True
    if fork_req.value == 'right_fork':
        _p.right_fork = ForkStates.clean
    elif fork_req.value == 'left_fork':
        _p.left_fork = ForkStates.clean
    else:
        raise Exception("Unknown value:", fork_req.value)


def send_rsp(_p: Philosopher, _message):
    request = _message.get('req')
    # send right fork
    if request == ForkRequests.need_right:  # his right fork is my left fork
        _p.left_fork = ForkStates.empty
        print(f"{_p} sending my left fork to {_message['id']}", flush=True)
        comm.send({"id": _p.id, "rsp": True}, dest=_message['id'])

    # send left fork
    elif request == ForkRequests.need_left:  # his left fork is my right fork
        _p.right_fork = ForkStates.empty
        print(f"{_p} sending my right fork to {_message['id']}", flush=True)
        comm.send({"id": _p.id, "rsp": True}, dest=_message['id'])
    else:
        raise Exception(f"{_p} is thinking! All messages should have 'req'! Message received: {_message}")


def think(_p: Philosopher, timeout: int):
    # print(f"{timeout_start} + {timeout} = {timeout_start + timeout}", flush=True)
    print(f"{_p} thinking for {timeout} seconds ...", flush=True)
    timeout_start = time.time()

    # double call of this if statement insures that if both neighbours are waiting, they get the forks right away
    for _ in range(2):
        if comm.iprobe():  # check if there are messages for this philosopher
            _message = comm.recv()
            send_rsp(_p, _message)

    while time.time() < timeout_start + timeout:  # thinking time

        if comm.iprobe():  # check if there are messages for this philosopher
            _message = comm.recv()
            send_rsp(_p, _message)

        if time.time() + 1 < timeout_start + timeout:  # after sleep the condition will be satisfied
            time.sleep(1)
        elif timeout_start + timeout - time.time() < 0.1:
            pass
        else:
            time.sleep(timeout_start + timeout - time.time() - 0.01)
    print(f"{_p} finished thinking", flush=True)



def get_forks(_p: Philosopher):

    while not _p.has_forks():
        print(f"{_p} getting forks [{_p.right_fork},{_p.left_fork}]", flush=True)  # one should be ForkStates.empty
        if _p.right_fork == ForkStates.empty:
            req_fork_and_wait_resp(_p, (_p.id - 1) % comm.Get_size(), fork_req=ForkRequests.need_right)
        if _p.left_fork == ForkStates.empty:
            req_fork_and_wait_resp(_p, (_p.id + 1) % comm.Get_size(), fork_req=ForkRequests.need_left)


def eat(_p: Philosopher, timeout: int):
    print(f"{_p} eating for {timeout} seconds ...", flush=True)
    time.sleep(timeout)
    _p.get_forks_dirty()
    print(f"{_p} finished eating", flush=True)


comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()
if size < 2:
    print("Only one philosopher is not enough", flush=True)
    exit(1)

if rank == 0:
    p = Philosopher(rank, ForkStates.dirty, ForkStates.dirty)
elif rank == size - 1:
    p = Philosopher(rank, ForkStates.empty, ForkStates.empty)
else:
    p = Philosopher(rank, left_fork=ForkStates.dirty)

print(f"{p} of {size} sitting at the table...", flush=True)
while True:
    think(p, random.randint(1, 5))
    if not p.has_forks():
        get_forks(p)
    eat(p, random.randint(1, 3))
    # print(f"{p} has {len(p.request_queue)} requests!", flush=True)
    for _, message in enumerate(p.request_queue):
        send_rsp(p, message)
    p.request_queue = []
print(f"{p} standing up and leaving!", flush=True)
