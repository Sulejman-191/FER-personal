The program makes the computer's move on the board in the given file.
The first argument is the current board, the second is the search depth.
An example board is given in 'ploca.txt', where '1' is CPU and '2' is human; dimensions are in the first row.

Example: <exe> ploca.txt 7