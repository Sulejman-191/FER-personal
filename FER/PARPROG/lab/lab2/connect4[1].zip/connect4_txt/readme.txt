
Program obavlja potez racunala na ploci zadanoj u datoteci te upisuje svoj potez u istu.

Prvi argument je datoteka s trenutnim stanjem, a drugi je dubina pretrazivanja.

Primjer datoteke s plocom mozete vidjeti u 'ploca.txt' (oznaka '1' je CPU, '2' je HUMAN, dimenzije su u prvom retku).

Primjer uporabe: <exe> ploca.txt 7